export class Contact {
  _id?: string;
  name: string;
  email: string;
  ssn: string;
  phone: {
    mobile: string;
  }
}
