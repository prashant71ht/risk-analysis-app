export class Risk {
    _id?: string;
    riskscore: string;
    riscode: string;
  }
